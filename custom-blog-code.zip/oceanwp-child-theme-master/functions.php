<?php
/**
 * OceanWP Child Theme Functions
 *
 * When running a child theme (see http://codex.wordpress.org/Theme_Development
 * and http://codex.wordpress.org/Child_Themes), you can override certain
 * functions (those wrapped in a function_exists() call) by defining them first
 * in your child theme's functions.php file. The child theme's functions.php
 * file is included before the parent theme's file, so the child theme
 * functions will be used.
 *
 * Text Domain: oceanwp
 * @link http://codex.wordpress.org/Plugin_API
 *
 */

/**
 * Load the parent style.css file
 *
 * @link http://codex.wordpress.org/Child_Themes
 */
function oceanwp_child_enqueue_parent_style() {

	// Dynamically get version number of the parent stylesheet (lets browsers re-cache your stylesheet when you update the theme).
	$theme   = wp_get_theme( 'OceanWP' );
	$version = $theme->get( 'Version' );

	// Load the stylesheet.
	wp_enqueue_style( 'child-style', get_stylesheet_directory_uri() . '/style.css', array( 'oceanwp-style' ), $version );
    wp_enqueue_style( 'custom-style', get_stylesheet_directory_uri() . '/css/style.css', array( 'oceanwp-style' ), $version );
    wp_enqueue_style( 'custom-font-style', get_stylesheet_directory_uri() . '/css/fonts.css', array( 'oceanwp-style' ), $version );
    wp_enqueue_style( 'custom-all-min-style', get_stylesheet_directory_uri() . '/css/all.min.css', array( 'oceanwp-style' ), $version );
    wp_enqueue_style( 'custom-all-owl-style',  'https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css');
    wp_enqueue_style( 'custom-all-owl2-style',  'https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css');
    

    wp_enqueue_script( 'script1', 'https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js' );
    wp_enqueue_script( 'script2', 'https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js' );
    wp_enqueue_script( 'script4', 'https://npmcdn.com/isotope-layout@3/dist/isotope.pkgd.js' );
    wp_enqueue_script( 'scriptjs5', get_stylesheet_directory_uri() . '/js/cstm.js', array(), $version  );
	
}

add_action( 'wp_enqueue_scripts', 'oceanwp_child_enqueue_parent_style' );


// Custom Carousel Custom Post Type
function carousel_init() {
    // set up Doctor labels
    $labels = array(
        'name' => 'Carousel',
        'singular_name' => 'Carousel',
        'add_new' => 'Add New Carousel',
        'add_new_item' => 'Add New Carousel',
        'edit_item' => 'Edit Carousel',
        'new_item' => 'New Carousel',
        'all_items' => 'All Carousel',
        'view_item' => 'View Carousel',
        'search_items' => 'Search Carousel',
        'not_found' =>  'No Carousel Found',
        'not_found_in_trash' => 'No Carousel found in Trash', 
        'parent_item_colon' => '',
        'menu_name' => 'Carousel',
    );
    
    // register post type
    $args = array(
        'labels' => $labels,
        'public' => true,
        'has_archive' => true,
        'show_ui' => true,
        'capability_type' => 'post',
        'hierarchical' => false,
        'rewrite' => array('slug' => 'carousel'),
        'query_var' => true,
        /*'menu_icon' => 'dashicons-plus-alt',*/
        'supports' => array(
            'title',
            'editor',
            'excerpt',
            'trackbacks',
            'custom-fields',
            'comments',
            'revisions',
            'thumbnail',
            'author',
            'page-attributes'
        )
    );
    register_post_type( 'carousel', $args );
    
    
}
add_action( 'init', 'carousel_init' );

// register taxonomy
    register_taxonomy('carousel', 'carousel', array('hierarchical' => true, 'label' => 'Carousel Category', 'query_var' => true, 'rewrite' => array( 'slug' => 'carousel-category' )));











add_shortcode('custom-carousel', 'add_custom_carousel');

function add_custom_carousel(){?>


    <section class="slider-section">
        <div class="container">
            <div class="row">
                <?php 

                        $args = array(  
                        'post_status' => 'publish',
                        'post_type'=> 'carousel',
                        'posts_per_page' => -1,  
                         );
                        $loop = new WP_Query( $args ); 
                         ?>

                <div class="w-100 slider">
                    <div class="owl-carousel owl-theme">
                        <?php 
                         while ( $loop->have_posts() ) : $loop->the_post(); 
                        ?>
                        <div class="item">
                            <div class="slider-hover">
                                <div class="slider-img mb-50">
                                    <?php $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID), 'thumbnail' ); ?>
                                    <img class="indus-sec-img" src="<?php echo $url ?>" alt="">
                                </div>
                                <div class="slider-content">
                                    <a href="<?php the_field('link'); ?>" class="btn btn-1"><?php the_field('button'); ?>
                                        <svg xmlns="http://www.w3.org/2000/svg" fill-rule="evenodd" clip-rule="evenodd"><path d="M21.883 12l-7.527 6.235.644.765 9-7.521-9-7.479-.645.764 7.529 6.236h-21.884v1h21.883z"/></svg>
                                        </a>
                                    
                                    <h4 class="mb-20"><?php the_title();  ?></h4>
                                    <p class="w-70"><?php the_excerpt(); ?></p>
                                </div>
                            </div>
                        </div>
                        <?php
                        endwhile;
                        wp_reset_postdata();
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <script type="text/javascript">
            $('.owl-carousel').owlCarousel({
                loop:false,
                margin:100,
                nav:true,
                responsive:{
                    0:{
                        items:1
                    },
                    600:{
                        items:2
                    },
                    1000:{
                        items:2
                    },
                    1200:{
                        items:2
                    }
                }
            })
    </script>
</body>

</html>

<?php }

/*-------------------------------------------------------------------------- BLOG SLIDER CUSTOM CODE BEGIN-------------------------------------------------------------------------- */

add_shortcode('custom-blog-carousel', 'add_custom_blog_carousel');

function add_custom_blog_carousel(){?>


<section class="blog-section">
        <div class="container">
            <div class="row">
                <?php 

                        $args = array(  
                        'post_status' => 'publish',
                        'post_type'=> 'post',
                        'posts_per_page' => -1,  
                         );
                        $loop = new WP_Query( $args ); 
                         ?>
<!--                 <div class="w-100 mb-50">
                    <h6 class="mb-10 d-inline-block">Blog</h6>
                    <div class="blog-header justify-content-space-between d-flex">
                        <h2 class="w-35">The quick, brown fox jumps over a lazy dog.</h2>
                    </div>
                </div> -->
                <div class="w-100 slider">
                    <div class="owl-carousel owl-theme blog-carousel">

                        <?php 
                         while ( $loop->have_posts() ) : $loop->the_post(); 
                        ?>

                        <div class="item blog-item">
                            <div class="blog-hover d-flex">
                                <div class="blog-img">
                                    <?php $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID), 'thumbnail' ); ?>
                                    <img src="<?php echo $url ?>" alt="">
                                </div>
                                <div class="blog-content">
                                    <div class="blog-main">
                                        <h2 class="mb-20"><?php the_title();  ?></h2>
                                        <p><?php the_excerpt(); ?></p>
                                    </div>
                                    <div class="blog-footer">
                                        <h5>
                                            <span class="blog-footer-icon">
                                                <img src="http://localhost/formproject/wp-content/uploads/2021/12/notes.svg" alt="">
                                            </span>
                                            <?php 
                                                $category = get_the_category( $post->ID );
                                                echo $category[0]->cat_name;?>
                                        </h5>
                                        <div class="blog-footer-btn btn-1">
                                            <svg xmlns="http://www.w3.org/2000/svg" fill-rule="evenodd" clip-rule="evenodd">
                                                <path
                                                    d="M21.883 12l-7.527 6.235.644.765 9-7.521-9-7.479-.645.764 7.529 6.236h-21.884v1h21.883z" />
                                            </svg>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php
                        endwhile;
                        wp_reset_postdata();
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </section>


<script type="text/javascript">
         $('.blog-carousel') .owlCarousel({
            loop: false,
            margin: 100,
            nav: true,
            responsive: {
                0: {
                    items: 1
                },
                600: {
                    items: 1
                },
                1000: {
                    items: 1
                },
                1200: {
                    items: 2
                }
            }
        });
    </script>



<?php }
/*-------------------------------------------------------------------------- BLOG SLIDER CUSTOM CODE END-------------------------------------------------------------------------- */
// Custom project Custom Post Type
function project_init() {
    // set up  labels
    $labels = array(
        'name' => 'Project',
        'singular_name' => 'Project',
        'add_new' => 'Add New Project',
        'add_new_item' => 'Add New Project',
        'edit_item' => 'Edit Project',
        'new_item' => 'New Project',
        'all_items' => 'All Projects',
        'view_item' => 'View Project',
        'search_items' => 'Search Project',
        'not_found' =>  'No Project Found',
        'not_found_in_trash' => 'No Project found in Trash', 
        'parent_item_colon' => '',
        'menu_name' => 'Project',
    );
    
    // register post type
    $args = array(
        'labels' => $labels,
        'public' => true,
        'has_archive' => true,
        'show_ui' => true,
        'capability_type' => 'post',
        'hierarchical' => false,
        'rewrite' => array('slug' => 'project'),
        'query_var' => true,
        /*'menu_icon' => 'dashicons-plus-alt',*/
        'supports' => array(
            'title',
            'editor',
            'excerpt',
            'trackbacks',
            'custom-fields',
            'comments',
            'revisions',
            'thumbnail',
            'author',
            'page-attributes'
        )
    );
    register_post_type( 'project', $args );
    
    
}
add_action( 'init', 'project_init' );

// register taxonomy
    register_taxonomy('project', 'project', array('hierarchical' => true, 'label' => 'Project Category', 'query_var' => true, 'rewrite' => array( 'slug' => 'project-category' )));




    /*---------------------------------------------------------------------- PROJECT FILTER GALLERY CUSTOM CODE START------------------------------------------------------------------------ */

    add_shortcode('custom-project-filter-post', 'add_custom_project_filter_post');


    function add_custom_project_filter_post(){
        
    $taxonomy     = 'project';
    $orderby      = 'name';
    $show_count   = 0;     // 1 for yes, 0 for no
    $pad_counts   = 0;     // 1 for yes, 0 for no
    $hierarchical = 1;     // 1 for yes, 0 for no
    $title        = the_title();
    $empty        = 1;
    $depth        = 1;
     
    $args = array(
    'taxonomy'     => $taxonomy,
    'orderby'      => $orderby,
    'show_count'   => $show_count,
    'pad_counts'   => $pad_counts,
    'hierarchical' => $hierarchical,
    'title_li'     => $title,
    'hide_empty'   => false,
    'parent'       => 0,
    'posts_per_page' => 5,
    'tax_query' => array(
            array(
                'taxonomy' => 'project',
                'field'            => 'term_id', // Means you'll use term id to determine your parent term.
                'include_children' => true,
                'operator'         => 'IN',
                'terms'            => $cat_id, // Your term or category ID
            ),
        ),
    'depth'        => $depth
    
);
$cats = get_categories( $args );
//echo '<pre>';
//print_r($cats);

$parent_cat_arg = array('hide_empty' => false, 'parent' => 0 );
$parent_cat = get_terms('project',$args);//category name

//$q = new WP_Query( $args );
$query = new WP_Query($args);
/*echo '<pre>';
print_r($query);*/?>




<h1>Isotope - filtering</h1>
<div class="button-group filters-button-group">
  <button class="button is-checked" data-filter="*">all</button>

    <?php
        foreach ($parent_cat as $catVal) {
        $cat_id = $catVal->term_id; 
                /*echo '<li class="sub-item-info"><a href="javascript:void(0)" class="dropdown-info">'.$catVal->name.'</a>';*/
                echo '<button class="button" data-filter=".metal">'.$catVal->name.'</button>';
                }
     ?>

  <!-- <button class="button" data-filter=".metal">metal</button> -->
  <!-- <button class="button" data-filter=".transition">transition</button> -->
  <!-- <button class="button" data-filter=".alkali, .alkaline-earth">alkali and alkaline-earth</button>
  <button class="button" data-filter=":not(.transition)">not transition</button>
  <button class="button" data-filter=".metal:not(.transition)">metal but not transition</button>
  <button class="button" data-filter="numberGreaterThan50">number > 50</button>
  <button class="button" data-filter="ium">name ends with &ndash;ium</button> -->
</div>

    <?php 
         $args = array(  
         'post_status' => 'publish',
         'post_type'=> 'project',
         'posts_per_page' => -1,  
          );
          
          $loop = new WP_Query( $args );
    ?>

    <div class="">
        <?php 
            while ( $loop->have_posts() ) : $loop->the_post(); 
        ?>

          <div class=" metal " data-category="transition">
            <div> 
                <div>
                    <?php $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID), 'thumbnail' ); ?>
                    <img class="indus-sec-img" src="<?php echo $url ?>" alt="">
                </div>
                <h3 class="name"><?php the_title();?></h3>
                <p><?php the_excerpt(); ?></p>

            </div>
          </div>
   
          <?php
                        endwhile;
                        wp_reset_postdata();
                        ?>
    </div>
  <!-- <div class="element-item metalloid " data-category="metalloid">
    <h3 class="name">Tellurium</h3>
    <p class="symbol">Te</p>
    <p class="number">52</p>
    <p class="weight">127.6</p>
  </div>
  <div class="element-item post-transition metal " data-category="post-transition">
    <h3 class="name">Bismuth</h3>
    <p class="symbol">Bi</p>
    <p class="number">83</p>
    <p class="weight">208.980</p>
  </div>
  <div class="element-item post-transition metal " data-category="post-transition">
    <h3 class="name">Lead</h3>
    <p class="symbol">Pb</p>
    <p class="number">82</p>
    <p class="weight">207.2</p>
  </div>
  <div class="element-item transition metal " data-category="transition">
    <h3 class="name">Gold</h3>
    <p class="symbol">Au</p>
    <p class="number">79</p>
    <p class="weight">196.967</p>
  </div>
  <div class="element-item alkali metal " data-category="alkali">
    <h3 class="name">Potassium</h3>
    <p class="symbol">K</p>
    <p class="number">19</p>
    <p class="weight">39.0983</p>
  </div>
  <div class="element-item alkali metal " data-category="alkali">
    <h3 class="name">Sodium</h3>
    <p class="symbol">Na</p>
    <p class="number">11</p>
    <p class="weight">22.99</p>
  </div>
  <div class="element-item transition metal " data-category="transition">
    <h3 class="name">Cadmium</h3>
    <p class="symbol">Cd</p>
    <p class="number">48</p>
    <p class="weight">112.411</p>
  </div>
  <div class="element-item alkaline-earth metal " data-category="alkaline-earth">
    <h3 class="name">Calcium</h3>
    <p class="symbol">Ca</p>
    <p class="number">20</p>
    <p class="weight">40.078</p>
  </div>
  <div class="element-item transition metal " data-category="transition">
    <h3 class="name">Rhenium</h3>
    <p class="symbol">Re</p>
    <p class="number">75</p>
    <p class="weight">186.207</p>
  </div>
  <div class="element-item post-transition metal " data-category="post-transition">
    <h3 class="name">Thallium</h3>
    <p class="symbol">Tl</p>
    <p class="number">81</p>
    <p class="weight">204.383</p>
  </div>
  <div class="element-item metalloid " data-category="metalloid">
    <h3 class="name">Antimony</h3>
    <p class="symbol">Sb</p>
    <p class="number">51</p>
    <p class="weight">121.76</p>
  </div>
  <div class="element-item transition metal " data-category="transition">
    <h3 class="name">Cobalt</h3>
    <p class="symbol">Co</p>
    <p class="number">27</p>
    <p class="weight">58.933</p>
  </div>
  <div class="element-item lanthanoid metal inner-transition " data-category="lanthanoid">
    <h3 class="name">Ytterbium</h3>
    <p class="symbol">Yb</p>
    <p class="number">70</p>
    <p class="weight">173.054</p>
  </div>
  <div class="element-item noble-gas nonmetal " data-category="noble-gas">
    <h3 class="name">Argon</h3>
    <p class="symbol">Ar</p>
    <p class="number">18</p>
    <p class="weight">39.948</p>
  </div>
  <div class="element-item diatomic nonmetal " data-category="diatomic">
    <h3 class="name">Nitrogen</h3>
    <p class="symbol">N</p>
    <p class="number">7</p>
    <p class="weight">14.007</p>
  </div>
  <div class="element-item actinoid metal inner-transition " data-category="actinoid">
    <h3 class="name">Uranium</h3>
    <p class="symbol">U</p>
    <p class="number">92</p>
    <p class="weight">238.029</p>
  </div>
  <div class="element-item actinoid metal inner-transition " data-category="actinoid">
    <h3 class="name">Plutonium</h3>
    <p class="symbol">Pu</p>
    <p class="number">94</p>
    <p class="weight">(244)</p>
  </div>
</div> -->
<?php }





















    /*---------------------------------------------------------------------- PROJECT FILTER GALLERY CUSTOM CODE END------------------------------------------------------------------------ */